/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplikasi_sendtoin;  

import java.util.ArrayList;
/**
 *
 * @author Zulfikar
 */
public class Pengirim extends User{
    private ArrayList<Paket> paket;
    private String alamat;
    
    public Pengirim(String usr,String pwd,String eml,String alamat,String role){
        super(usr,pwd,eml,role);
        this.alamat = alamat;
        this.paket = new ArrayList<>();
    }
    
    public void setPacket(){
        this.paket = paket;
    }
    
    public void removePacket(Paket p){
        this.paket.remove(p);
    }
    public void addPacket(Paket p){
        this.paket.add(p);
    }
    public void setAlamat(String alamat){
        this.alamat = alamat;
    }
    public String getAlamat(){
        return alamat;
    }
    public ArrayList<Paket> getPaket(){
        return this.paket;
    }
    
    
}
