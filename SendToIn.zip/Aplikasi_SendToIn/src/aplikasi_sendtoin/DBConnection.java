/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


package aplikasi_sendtoin;

import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Zulfikar
 */
public class DBConnection {
    
    private static Connection DBConnection;
    public static Connection getKoneksi() throws SQLException {
      if(DBConnection==null){
        try {
         String URL = "jdbc:mysql://localhost/sendtoin";
         String USERNAME = "root";
         String PASSWORD = "";
         DriverManager.registerDriver(new com.mysql.jdbc.Driver());
         DBConnection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "error koneksi");
        }
      }return DBConnection;
    }
    static Object getConnection(){
        throw new UnsupportedOperationException("Not yet implemented");
    }
}


    
    


