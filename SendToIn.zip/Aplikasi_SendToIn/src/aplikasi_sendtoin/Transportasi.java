/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplikasi_sendtoin;

/**
 *
 * @author Zulfikar
 */
public class Transportasi {
    private String jenisTransportasi;
    private double biayaPerMile;
    
    public Transportasi(String jenisTransportasi,double biayaPerMile){
        this.jenisTransportasi = jenisTransportasi;
        this.biayaPerMile = biayaPerMile;
    }
    
    public void setJenis(String jenisTransportasi){
        this.jenisTransportasi = jenisTransportasi;
    }
    public void setBiaya(double biayaPerMile){
        this.biayaPerMile = biayaPerMile;
    }
    public String getJenis(){
        return this.jenisTransportasi;
    }
    
    public double getBiaya(){
        return this.biayaPerMile;
    }
    
}
