/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplikasi_sendtoin;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

/**
 *
 * @author Zulfikar
 */
public class Paket {
    private String idPacket;
    private LocalDate tanggalShipment;
    private ArrayList<Barang> barang;
    private double beratPacket;
    private float hargaPacket;
    private String destinasi;
    
    
    public Paket(String id,LocalDate tgl_ship,String destinasi){
        this.idPacket = id;
        this.tanggalShipment = tgl_ship;
        this.destinasi = destinasi;
        this.barang = new ArrayList<Barang>();
    }
    
    public void addBarang(Barang p){
        this.barang.add(p);
        this.hargaPacket += p.getHarga();
        this.beratPacket += p.getBerat();
    }
    
    public ArrayList<Barang> getBarang(){
        return this.barang;
    }
    
    public void setDestinasi(String destinasi){
        this.destinasi = destinasi;
    }
    
    public LocalDate getTanggal(){
        return this.tanggalShipment;
    }
    
    public String getDestinasi(){
        return this.destinasi;
    }
    
    public double getHargaPacket(){
        return this.hargaPacket;
    }
    
    public String getId(){
        return this.idPacket;
    }
    
    public void printBarang(){
        for(int i = 0; i < this.barang.size();i++){
            System.out.println(this.barang.get(i));
        }
    }
}
