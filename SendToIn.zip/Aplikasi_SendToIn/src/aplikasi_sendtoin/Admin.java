/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplikasi_sendtoin;

import java.util.ArrayList;


/**
 *
 * @author Zulfikar
 */
public class Admin extends User{
    private ArrayList<Barang> barang;
    
    public Admin(String usr,String pwd,String eml,String role){
        super(usr,pwd,eml,role);
        this.barang = new ArrayList<>();
    }
    public void addBarang(Barang p){
        this.barang.add(p);
    }
    public void removeBarang(Barang p){
        this.barang.remove(p);
    }
    
    public void editBarang(int index,Barang p){
        barang.set(index,p);
    }
    
}
