/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplikasi_sendtoin;

import java.time.LocalDate;

/**
 *
 * @author Zulfikar
 */
public class Barang {
    private String namaBarang;
    private double beratBarang;
    private String jenisBarang;
    private double hargaBarang;
    
    public Barang(String nama,String jenis,double harga,double beratBarang){
        this.namaBarang = nama;
        this.jenisBarang = jenis;
        this.hargaBarang = harga;
        this.beratBarang = beratBarang;
    }
    
    public String getNama(){
        return this.namaBarang;
    }

    
    public double getHarga(){
        return this.hargaBarang;
    }
    
    public double getBerat(){
        return this.beratBarang;
    }
    
    public String getJenis(){
        return this.jenisBarang;
    }
}
