/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplikasi_sendtoin;

import java.util.ArrayList;

/**
 *
 * @author Zulfikar
 */
public class User implements Loginable {
    private String username;
    private String password;
    private String email;
    private String role;
    private boolean loggedIn;
    
    public User(String usr,String pwd,String eml,String role){
        this.username = usr;
        this.password = pwd;
        this.email = eml;
        this.role = role;
        this.loggedIn = false;
    }
    
    @Override
    public boolean login(String username, String password) {
    if (this.username.equals(username) && this.password.equals(password)) {
      this.loggedIn = true;
      return true;
    }
    return false;
  }
    
    @Override
    public void logout() {
      this.loggedIn = false;
    }
    
    public String getRole(String role){
        return this.role = role;
    }
  
    public void editAccount(String username,String password,String email){
        this.username = username;
        this.password = password;
        this.email = email;
    }
    public String setEmail(String email){
        return this.email = email;
    }
    public String getUsername(){
        return username;
    }
    
    public String getPassword(){
        return password;
    }
    
    public void setUsername(String username){
        this.username = username;
    }
    
    public String getEmail(){
        return email;
    }
}
