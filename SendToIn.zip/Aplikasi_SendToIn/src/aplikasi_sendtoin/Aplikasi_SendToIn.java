/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplikasi_sendtoin;

import com.mysql.jdbc.Driver;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author Zulfikar
 */
public class Aplikasi_SendToIn {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // TODO code application logic here
        // Create instances of user subclasses

        LocalDate date = LocalDate.of(2021,1,24);
        Paket paket = new Paket("234",date,"Katapang");
        Pengirim pengirim = new Pengirim ("zeki", "zeki123", "zekiii", "bandung","pengirim");
        Transportasi transportasi = new Transportasi ("PickUp", 12.3);
        Barang barang = new Barang ("Charger", "Elektronik", 14.0000, 5.2);
        Admin admin = new Admin ("Rizalll", "rizalll123", "rizal32@gmail.com","admin");
        
        paket.addBarang(barang);

        admin.setUsername("Halooow");
        System.out.println("Nama User : " + admin.getUsername());
        
        admin.addBarang(barang);
        
        pengirim.addPacket(paket);
        
        paket.printBarang();
        
        LoginGUI mainframe = new LoginGUI();
        mainframe.setVisible(true);  
    }
}
