/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aplikasi_sendtoin;

import java.util.ArrayList;

/**
 *
 * @author Zulfikar
 */
public class Kurir extends User{    
    private Transportasi transportasi;
    private ArrayList<Paket> paket;
    
    public Kurir(String usr,String pwd,String eml,String role){
        super(usr,pwd,eml,role);
    }
    
    public void setTransportasi(Transportasi t){
        this.transportasi = t;
    }
    public Transportasi getTransportasi(){
        return this.transportasi;
    }
    
    public ArrayList<Paket> getPaket(){
        return this.paket;
    }
    
    public double calculateOngkir(double jarak){
        return jarak * this.transportasi.getBiaya();
    }
}
